package com.citymanagement.UI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.MouseMotionAdapter;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.citymanagement.geometry.Rectangle;
import com.citymanagement.geometry.Drawable;

public class CustomDrawingPanel extends JPanel {
	
	private static final long serialVersionUID = 1L;
	
	private List<Drawable> _graphicsElementsList;
	
	private static Camera _mainCamera;

	public List<Drawable> get_graphicsElementsList() {
		return _graphicsElementsList;
	}

	public CustomDrawingPanel() {
        setBorder(BorderFactory.createLineBorder(Color.black));
        setMouseEvents();
        
        _graphicsElementsList = new ArrayList<Drawable>();
        
		_mainCamera = new Camera();
		addMouseListener(_mainCamera);
		addMouseMotionListener(_mainCamera);
    }
	
	private void setMouseEvents() {
		 addMouseListener(new MouseAdapter() {
	            public void mousePressed(MouseEvent e) {
	                //moveSquare(e.getX(),e.getY());
	            }
	        });

	        addMouseMotionListener(new MouseAdapter() {
	            public void mouseDragged(MouseEvent e) {
	                //moveSquare(e.getX(),e.getY());
	            }
	        });
	}

	public void addNewGraphicElement(Drawable shape) {
		get_graphicsElementsList().add(shape);
	}
	
	public void removeGraphicElement(Drawable shape) {
		int i = get_graphicsElementsList().indexOf(shape);
		get_graphicsElementsList().remove(i);
	}
	
    public Dimension getPreferredSize() {
        return new Dimension(1400,800);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
		
        for (Drawable e : _graphicsElementsList) {
			e.drawShape(g);
		}
    }

	public static Camera get_mainCamera() {
		return _mainCamera;
	}
    
}
