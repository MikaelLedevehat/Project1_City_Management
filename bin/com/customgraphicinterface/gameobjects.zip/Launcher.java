package com.citymanagement;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import com.citymanagement.UI.MainWindow;
import com.citymanagement.gameobjects.GameManager;

public class Launcher {

	public static void main(String[] args) {

		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				MainWindow mainWindow = MainWindow.getInstance();
				GameManager gm = new GameManager();
				mainWindow.run();
			}
		});
	}
}
