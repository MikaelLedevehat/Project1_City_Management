package com.citymanagement.utilities;

public class Utile {
	public static void SO (Object... g) {
		for (Object o : g) {
			System.out.print(o);
		}
		System.out.println();
	}
}
