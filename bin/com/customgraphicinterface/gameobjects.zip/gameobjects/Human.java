package com.citymanagement.gameobjects;

import java.awt.Color;
import java.util.Comparator;

import com.citymanagement.UI.MainWindow;
import com.citymanagement.gameobjects.Ressource.RessourceType;
import com.citymanagement.geometry.Rectangle;
import com.citymanagement.utilities.Vector2;

public class Human extends GameObject {

	private class Needs{

		public static final float NEED_MAX_CAP = 200;
		public static final float HUNGER_GROW_RATE = 0.05f;
		public static final float THIRST_GROW_RATE = 0.1f;
		public static final float REPRODUCTIVE_URGE_GROW_RATE = 0.05f;

		private float _thirst;
		private float _hunger;
		private float _reproductiveUrge;

		public Needs(int t, int h, int r){
			set_hunger(h);
			set_reproductiveUrge(r);
			set_thirst(t);
		}

		public Needs(){
			this(0,0,0);
		}

		public float get_hunger(){
			return _hunger;
		}
		public float get_thirst(){
			return _thirst;
		}
		public float get_reproductiveUrge(){
			return _reproductiveUrge;
		}

		public void set_hunger(float h) {
			if(h < 0) this._hunger = 0;
			else if(Needs.NEED_MAX_CAP < h) this._hunger = Needs.NEED_MAX_CAP;
			else this._hunger = h;
		}
		public void set_thirst(float t) {
			if(t < 0) this._thirst = 0;
			else if(Needs.NEED_MAX_CAP < t) this._thirst = Needs.NEED_MAX_CAP;
			else this._thirst = t;
		}
		public void set_reproductiveUrge(float r) {
			if(r < 0) this._reproductiveUrge = 0;
			else if(Needs.NEED_MAX_CAP < r) this._reproductiveUrge = Needs.NEED_MAX_CAP;
			else this._reproductiveUrge = r;
		}

		public void updateAllNeeds(){
			set_hunger(get_hunger() + Needs.HUNGER_GROW_RATE);
			set_thirst(get_thirst() + Needs.THIRST_GROW_RATE);
			set_reproductiveUrge(get_reproductiveUrge() + Needs.REPRODUCTIVE_URGE_GROW_RATE);
		}
	}

	public class Destination {
		public Vector2 pos;
		public boolean fixe;
		public GameObject target;
	}

	public static class HumanComparator implements Comparator<Human>{

		@Override
		public int compare(Human arg0, Human arg1) {
			// TODO Auto-generated method stub
			if(arg0.get_id() == arg1.get_id()) return 0;
			else if(arg0.get_id() < arg1.get_id()) return 1;
			else return -1;
		}
	}

	private interface GoalWorker{
		void execute();
	}

	public enum SexType {
		MALE,
		FEMALE,
	}

	private enum GoalType{
		WANDER,
		DRINK,
		EAT,
		REPRODUCE,
	}



	public static final int HUMANHEIGHT = 10;
	public static final int HUMANWIDTH = 10;
	public static final Color INTERACTION_COLOR = Color.green;
	public static final float SPEED = 3f;
	public static final float INTERATION_SPEED = 0.8f;
	
	private static int humanIdIncrementor = 0;

	public final GameManager world;

	private Settings[] _settings = new Settings[]{
		new Settings(Color.black, Color.blue, 2, false),
		new Settings(Color.black, Color.pink, 2, false),
	};
	private final int _id;
	private Rectangle _mesh;
	private SexType _sex;
	private Destination _dest;
	private Needs _needs;
	private GoalType _currentGoal;
	private float _interactionTimer = 0;
	private boolean _isInteracting = false;
	private Color _colorSave;
	private Human _currentPartner;
	private GoalWorker[] _goalWorkers = new GoalWorker[]{
		new GoalWorker(){ public void execute() { wander(); } },
		new GoalWorker(){ public void execute() { drink(); } },
		new GoalWorker(){ public void execute() { eat(); } },
		new GoalWorker(){ public void execute() { reproduce(); } },
	};

	public int get_id() {
		return this._id;
	}

	public void set_destination(Vector2 dest , boolean fixe, GameObject t) {
		_dest = new Destination();
		_dest.pos = dest;
		_dest.fixe = fixe;
		_dest.target = t;
	}

	public Vector2 get_pos(){
		return _mesh.get_pos();
	}

	public void set_pos(Vector2 p){
		_mesh.set_pos(p);
	}
	
	public void set_goal(GoalType g){
		_currentGoal = g;
	}

	public SexType get_sex(){
		return _sex;
	}

	public void set_sex(SexType t){
		_sex = t;
	}

	public Human(GameManager world, SexType sex, Vector2 pos) {
		// TODO Auto-generated constructor stub
		_id = Human.humanIdIncrementor;
		this.world = world;
		_sex = sex;
		Human.humanIdIncrementor++;
		_mesh = new Rectangle(HUMANHEIGHT, HUMANWIDTH, pos, (float)Math.toRadians(0), _settings[_sex.ordinal()].borderColor, _settings[_sex.ordinal()].borderSize, _settings[_sex.ordinal()].fillColor, false);
		_needs = new Needs(0,0,100);
	}
		
	@Override
	public void update() {
		_needs.updateAllNeeds();
		checkIfAlive();

		if( _dest != null) {
			if(arrived()){
				if(_isInteracting) interact();
				else executeGoal();
			} 
			else {
				if(_dest.fixe == false) updateDestination();
				moveTowardDestination();
			}
		}else {
			selectDestination();
		}
	}

	protected void updateDestination() {
		set_destination(_dest.target.get_pos(), false, _currentPartner);
	}

	protected void checkIfAlive() {
		//if(_needs.get_hunger() >= Needs.NEED_MAX_CAP) die();
		//if(_needs.get_thirst() >= Needs.NEED_MAX_CAP) die();
	}

	protected void selectDestination() {
		/*if(_needs.get_thirst() > 50){
			set_destination(findNearestWaterSource(), true, null);
			set_goal(GoalType.DRINK);
		} 
		else if(_needs.get_hunger() > 50){
			set_destination(findNearestFood(), true, null);
			set_goal(GoalType.EAT);
		} 
		else*/ if(_needs.get_reproductiveUrge() > 100){
			set_destination(findSuitableNearestPartner(), false, _currentPartner);
			set_goal(GoalType.REPRODUCE);
		}

		if(_dest == null){
			set_destination(selectRadomPlaceAround(200), true, null);
			set_goal(GoalType.WANDER);
		}
	}

	protected void executeGoal(){
		if(_currentGoal != null) _goalWorkers[_currentGoal.ordinal()].execute();
	}

	protected boolean drink(){
		_needs.set_thirst(0);
		interact();
		return true;
	}

	protected boolean eat(){
		_needs.set_hunger(0);
		interact();
		return true;
	}

	protected boolean reproduce(){
		_needs.set_reproductiveUrge(0);
		interact();
		world.addHumanToPopulation(_sex == SexType.MALE?this:_currentPartner, _sex == SexType.FEMALE?this:_currentPartner);
		return true;
	}

	protected void interact() {
		if(_interactionTimer > 100){
			_mesh.set_fillColor(_colorSave);
			_interactionTimer = 0;
			_dest = null;
			_isInteracting = false;
		}else{
			if(_mesh.get_fillColor() != Human.INTERACTION_COLOR) {
				_colorSave = _mesh.get_fillColor();
				_mesh.set_fillColor(Human.INTERACTION_COLOR);
			}
			_interactionTimer += Human.INTERATION_SPEED;
			_isInteracting = true;
		}
	}

	protected boolean wander(){
		_dest = null;
		return true;
	}

	protected Vector2 findNearestWaterSource(){
		Vector2 nearestSource = null;
		for(Terrain t : world.get_waterSources()){
			if(nearestSource == null) nearestSource = t.get_pos();
			else if(Vector2.dist(get_pos(), nearestSource) > Vector2.dist(get_pos(), t.get_pos())) nearestSource = t.get_pos();
		}
		return nearestSource;
	}
	
	protected Vector2 findNearestFood(){
		Vector2 nearestFood = null;
		
		for(Ressource r : world.get_ressources()){
			if(r.get_ressourceType() == RessourceType.FOOD){
				if(nearestFood == null) nearestFood = r.get_pos();
				else if(Vector2.dist(get_pos(), nearestFood) > Vector2.dist(get_pos(), r.get_pos())) nearestFood = r.get_pos();
			}
		}
		return nearestFood;
	}

	protected Vector2 findSuitableNearestPartner(){
		
		Vector2 nearestParner = null;
		for(Human h : world.get_populationList()){
			if(h.get_sex() != _sex){
				if(nearestParner == null){
					nearestParner = h.get_pos();
					_currentPartner = h;
				}
				else if(Vector2.dist(get_pos(), nearestParner) > Vector2.dist(get_pos(), h.get_pos())){
					nearestParner = h.get_pos();
					_currentPartner = h;
				} 
			}
		}
		
		return nearestParner;
	}

	protected Vector2 selectRadomPlaceOnWorld(int w, int h, int x, int y) {
		return new Vector2((float)Math.random()*w + x,
				(float)Math.random()*h + y);
	}

	protected Vector2 selectRadomPlaceAround(float maxRadius) {
		float angle = (float)(Math.random()*Math.PI);
		float radius = (float)(Math.random()*maxRadius);
		return get_pos().plus( new Vector2((float)(Math.cos(angle) * radius), (float)(Math.sin(angle) * radius)));
	}

	protected boolean arrived() {
		// TODO Auto-generated method stub
		if(Math.abs(_dest.pos.x -_mesh.get_pos().x) < 1f+SPEED && Math.abs(_dest.pos.y -_mesh.get_pos().y) < 1f+SPEED) return true;
		else return false;
	}
	
	protected void moveTowardDestination() {
		
		Vector2 distNormalized = Vector2.normalize(_dest.pos.minus(_mesh.get_pos()));
		_mesh.set_rotation((float)Math.atan2(distNormalized.y, distNormalized.x));
		_mesh.set_pos(_mesh.get_pos().plus(distNormalized.multiply(SPEED)));
	}

	protected void die(){
		//_mesh = null;
		MainWindow.getMainCanvas().removeGraphicElement(this._mesh);
		world.removeHumanFromPopulation(this);
		try {
			this.finalize();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
