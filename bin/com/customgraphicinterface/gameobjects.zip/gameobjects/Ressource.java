package com.citymanagement.gameobjects;

import com.citymanagement.geometry.Circle;
import com.citymanagement.utilities.Vector2;
import java.awt.Color;

public class Ressource extends GameObject{

    private Settings[] _settings = new Settings[]{
		new Settings(new Color(150,150,0), new Color(255,255,0),4, false),
	};

    public enum RessourceType{
        FOOD,
    }

    Circle _mesh;
    RessourceType _type;

    public RessourceType get_ressourceType(){
        return _type;
    }

    public Vector2 get_pos(){
        return _mesh.get_pos();
    }

    public void set_pos(Vector2 p){
        _mesh.set_pos(p);
    }

    public Ressource(RessourceType t, Vector2 pos){
        _type = t;
        _mesh = new Circle(10, pos, _settings[t.ordinal()].fillColor, _settings[t.ordinal()].borderColor, _settings[t.ordinal()].borderSize);
    }

    @Override
    public void update() {
        // TODO Auto-generated method stub
        
    }

    public void used(){

    }
    

}
