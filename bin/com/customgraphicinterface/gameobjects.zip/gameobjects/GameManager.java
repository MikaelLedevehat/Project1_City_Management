package com.citymanagement.gameobjects;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import com.citymanagement.UI.MainWindow;
import com.citymanagement.gameobjects.Ressource.RessourceType;
import com.citymanagement.geometry.Circle;
import com.citymanagement.geometry.Rectangle;
import com.citymanagement.geometry.Text;
import com.citymanagement.utilities.Utile;
import com.citymanagement.utilities.Vector2;
import static com.citymanagement.utilities.Utile.SO;

public final class GameManager{

	public final static int INITIAL_POPULATION = 5;
	
	private List<Human> _populationList;
	private Terrain _baseTerrain;
	private ArrayList<Terrain> _waterSources;
	private ArrayList<Ressource> _ressources;
	private Text t;

	public ArrayList<Terrain> get_waterSources() {
		return this._waterSources;
	}

	public GameManager() {
		//r = new Rectangle(100, 100, new Vector2(0,0), 0, Color.BLUE, 2, Color.green, false);
		
		_populationList = new ArrayList<Human>();
		_baseTerrain = new Terrain(Terrain.Type.GRASS,MainWindow.getMainCanvas().getHeight(), MainWindow.getMainCanvas().getWidth(), new Vector2(0,0));
		_waterSources = new ArrayList<>();
		_ressources = new ArrayList<>();

		int nbWaterSrc = (int)(Math.random() * 15) + 2;
		for(int i=0;i < nbWaterSrc;i++){
			_waterSources.add(new Terrain(Terrain.Type.WATER, 50, 50, new Vector2((int) (Math.random() * _baseTerrain.get_width()*2), (int) (Math.random() * _baseTerrain.get_height()*2))));
		}
		
		createNewHumanPopulation();
		createRessources();
		t = new Text(null, "Alive Human : " + _populationList.size());


	}

	private void createRessources() {
		for(int i=0;i<50;i++){
			_ressources.add(new Ressource(Ressource.RessourceType.FOOD, new Vector2((int) (Math.random() * _baseTerrain.get_width()*2), (int) (Math.random() * _baseTerrain.get_height()*2))));
		}
		//_waterSources.add(new Terrain(Terrain.Type.WATER, 5, 5, new Vector2(230,310)));
		//c = new Circle(10, new Vector2(230,310), Color.black, null, 4);
	}

	private void createNewHumanPopulation() {
		
		for(int i=0; i<1 ;i++) {
			get_populationList().add(new Human(this,Human.SexType.MALE, new Vector2((int)(Math.random()*_baseTerrain.get_height()), (int)(Math.random()*_baseTerrain.get_width()))));
		}

		for(int i=0; i<1 ;i++) {
			get_populationList().add(new Human(this,Human.SexType.FEMALE, new Vector2((int)(Math.random()*_baseTerrain.get_height()), (int)(Math.random()*_baseTerrain.get_width()))));
		}
		
	}

	public List<Human> get_populationList() {
		return _populationList;
	}

	public List<Ressource> get_ressources(){
		return _ressources;
	}

	public void removeHumanFromPopulation(Human h){
		_populationList.remove(h);
	}
	
	public void addHumanToPopulation(Human male, Human female){
		_populationList.add(new Human(this, Human.SexType.values()[(int)Math.round(Math.random())], female.get_pos()));
	}
	
}
