package com.citymanagement.gameobjects;

import java.util.ArrayList;

import org.eclipse.swt.graphics.Rectangle;

import com.citymanagement.UI.MainWindow;
import com.citymanagement.utilities.Vector2;

public abstract class GameObject {
	private static int _gameObjectIdCounter = 0;
	private static ArrayList<GameObject> _gameObjectList;
	private static ArrayList<GameObject> _oldGameObjectList;
	private long _gameObjectId;
	
	public static ArrayList<GameObject> getOldGameObjectList() {
		return GameObject._oldGameObjectList;
	}
	
	public static ArrayList<GameObject> getGameObjectList() {
		return GameObject._gameObjectList;
	}
	
	public static void updateGameObjectList() {
		GameObject._oldGameObjectList.clear();
		GameObject._oldGameObjectList.addAll(GameObject._gameObjectList);
	}
	
	public static void initGameObjectList() {
		GameObject._gameObjectList = new ArrayList<GameObject>();
		GameObject._oldGameObjectList = new ArrayList<GameObject>();
	}
	
	public GameObject() {
		_gameObjectId = GameObject._gameObjectIdCounter;
		GameObject._gameObjectIdCounter ++;
		GameObject._gameObjectList.add(this);
	}
	
	@SuppressWarnings("deprecation")
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
		_gameObjectList.remove(_gameObjectList.indexOf(this));
	}
	
	public long getId() {
		return _gameObjectId;
	}
	
	public abstract void update();
	public abstract Vector2 get_pos();
	public abstract void set_pos(Vector2 p);
}
