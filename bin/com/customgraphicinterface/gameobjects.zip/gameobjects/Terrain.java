package com.citymanagement.gameobjects;

import java.awt.Color;
import java.util.ArrayList;

import com.citymanagement.geometry.Rectangle;
import com.citymanagement.utilities.Vector2;


public class Terrain extends GameObject{

	public enum Type {
		GRASS,
		WATER
	}

	private Settings[] _settings = new Settings[]{
		new Settings(new Color(0,153,76), new Color(0,255,128),4, true),
		new Settings(new Color(0,0,204), new Color(51,51,204),4, false),
	};

	//public static final int GRASS = 0;
	//public static final int WATER = 1;


	private Rectangle _boundaries;

	public int getHeight(){
		return _boundaries.getHeight();
	}

	public void setHeight(int h){
		_boundaries.setHeight(h);
	}

	public int getWidth(){
		return _boundaries.getWidth();
	}

	public void setWidth(int w){
		_boundaries.setWidth(w);
	}

	public Vector2 getPos(){
		return _boundaries.getPos();
	}

	public void set_pos(Vector2 p){
		_boundaries.set_pos(p);
	}

	public Terrain(Type type, int height, int width, Vector2 pos) {
		// TODO Auto-generated constructor stub
		_boundaries = new Rectangle(height, width, pos,0,_settings[type.ordinal()].borderColor,_settings[type.ordinal()].borderSize,_settings[type.ordinal()].fillColor, _settings[type.ordinal()].lockedOnScreen);
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}
}
