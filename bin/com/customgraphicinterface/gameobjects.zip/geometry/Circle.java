package com.citymanagement.geometry;

import java.awt.Graphics;

import java.awt.Graphics2D;

import com.citymanagement.UI.Camera;
import com.citymanagement.UI.CustomDrawingPanel;
import com.citymanagement.utilities.Vector2;

import java.awt.Shape;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;

import org.eclipse.osgi.internal.debug.Debug;

public class Circle extends Drawable{

    private final Ellipse2D _circle;
    private float _radius;

    public float getRadius(){
        return _radius;
    }

    public void setRadius(float r){
        _radius = r;
    }

    public Circle(float radius, Vector2 pos, Color fillColor, Color borderColor, int borderSize){
        super(new Ellipse2D.Double());
        _circle = (Ellipse2D) getShape();
        setBorderColor(borderColor);
        setFillColor(fillColor);
        setBorderSize(borderSize);
        setRadius(radius);
        setPos(pos);
    }

    @Override
    public void drawShape(Graphics g) {

        Graphics2D g2d = (Graphics2D)g;
		AffineTransform old = g2d.getTransform();
		
		Camera camera = CustomDrawingPanel.get_mainCamera();
		if(camera == null) {
			System.err.println("Error : Camera is null");
			return;
		}
		g2d.translate(_circle.getCenterX() + (getLockedOnScreen() == false ? camera.get_pos().x:0),_circle.getCenterY() + (getLockedOnScreen() == false ? camera.get_pos().y:0));
		if(getFillColor() != null) {
			g2d.setColor(getFillColor());
			g2d.fill(_circle);
		}
		
		if(getBorderColor() != null) {
			g2d.setColor(getBorderColor());
			g2d.setStroke(new BasicStroke(getBorderSize()));
			g2d.draw(_circle);
		}
		g2d.setTransform(old);
    }

    @Override
    public void setPos(Vector2 v) {
        setPos(v);
        _circle.setFrame(v.x/2f- _radius, v.y/2f - _radius, _radius*2, _radius*2);
    }
}
