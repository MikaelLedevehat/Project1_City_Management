package com.citymanagement.geometry;

import java.awt.Graphics;

import java.awt.Color;
import java.awt.Shape;

import com.citymanagement.UI.MainWindow;
import com.citymanagement.utilities.Vector2;

abstract public class Drawable {
	private static int _shapeIdCounter = 0;
	private final long _shapeId;

	private Color _fillColor;
	private Color _borderColor;
	private int _borderSize;
	private Vector2 _pos;
	private boolean _lockedOnScreen;
	private Shape _shape;


	protected Shape getShape(){
		return _shape;
	}

	protected void setShape(Shape s){
		_shape = s;
	}

	public Color getFillColor() {
		return this._fillColor;
	}

	public void setFillColor(Color _fillColor) {
		this._fillColor = _fillColor;
	}

	public Color getBorderColor() {
		return _borderColor;
	}

	public void setBorderColor(Color _borderColor) {
		this._borderColor = _borderColor;
	}

	public int getBorderSize() {
		return _borderSize;
	}

	public void setBorderSize(int _borderSize) {

		this._borderSize = _borderSize;
	}
	
	public boolean getLockedOnScreen() {
		return _lockedOnScreen;
	}

	public void setLockedOnScreen(Boolean l) {
		this._lockedOnScreen = l;
	}

	public Vector2 getPos() {
		return _pos;
	}

	public Drawable(Shape s) {
		_shapeId = Drawable._shapeIdCounter;
		_shape = s;
		Drawable._shapeIdCounter++;
		MainWindow.getMainCanvas().get_graphicsElementsList().add(this);
	}
	
	public long getShapeId() {
		return _shapeId;
	}

	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
		int i = MainWindow.getMainCanvas().get_graphicsElementsList().indexOf(this);
		MainWindow.getMainCanvas().get_graphicsElementsList().remove(i);
	}
	
	abstract public void drawShape(Graphics g);
	abstract public void setPos(Vector2 v);
}
