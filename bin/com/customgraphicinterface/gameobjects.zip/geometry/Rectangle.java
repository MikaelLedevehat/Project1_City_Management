package com.citymanagement.geometry;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

import com.citymanagement.UI.Camera;
import com.citymanagement.UI.CustomDrawingPanel;
import com.citymanagement.gameobjects.GameManager;
import com.citymanagement.utilities.Vector2;

public class Rectangle extends Drawable {

	private final java.awt.Rectangle _rectangle;
	private float _rotation;

	public int getHeight() {
		return _rectangle.height;
	}

	public void setHeight(int height) {
		this._rectangle.height = height;
	}

	public int getWidth() {
		return _rectangle.width;
	}

	public void setWidth(int width) {
		this._rectangle.width = width;
	}
	
	public void setPos(Vector2 pos) {
		setPos(pos);
		_rectangle.x = (int)pos.x;
		_rectangle.y = (int)pos.y;
	}
	
	public float getRotation() {
		return _rotation;
	}

	public void setRotation(float rotation) {
		this._rotation = rotation;
	}

	public Rectangle(int height,int width,Vector2 pos,  float rotation, Color borderColor, int borderSize, Color fillColor, boolean lockedOnScreen ) {
		// TODO Auto-generated constructor stub
		super(new java.awt.Rectangle());
		_rectangle = (java.awt.Rectangle) getShape();
		setPos(new Vector2());
		setLockedOnScreen(lockedOnScreen);
		setWidth(width);
		setHeight(height);
		setBorderColor(borderColor);
		setRotation(rotation);
		setFillColor(fillColor);
		setPos(pos);
		setBorderSize(borderSize);
	}

	@Override
	public void drawShape(Graphics g) {
		
		Graphics2D g2d = (Graphics2D)g;
		AffineTransform old = g2d.getTransform();
		
		Camera camera = CustomDrawingPanel.get_mainCamera();
		if(camera == null) {
			System.err.println("Error : Camera is null");
			return;
		}
		g2d.translate(_rectangle.getCenterX() + (getLockedOnScreen() == false ? camera.get_pos().x:0),_rectangle.getCenterY() + (getLockedOnScreen() == false ? camera.get_pos().y:0));
		int xSave = _rectangle.x;
		int ySave = _rectangle.y;
		_rectangle.x = -_rectangle.width/2;
		_rectangle.y = -_rectangle.height/2;
		g2d.rotate(getRotation());
		if(getFillColor() != null) {
			g2d.setColor(getFillColor());
			g2d.fill(_rectangle);
		}
		
		if(getBorderColor() != null) {
			g2d.setColor(getBorderColor());
			g2d.setStroke(new BasicStroke(getBorderSize()));
			g2d.draw(_rectangle);
		}
		
		_rectangle.x = xSave;
		_rectangle.y = ySave;
		g2d.setTransform(old);
	}

}
