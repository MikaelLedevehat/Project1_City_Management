package com.citymanagement.geometry;

import java.awt.Graphics;
import java.awt.Shape;

import com.citymanagement.gameobjects.GameObject;
import com.citymanagement.utilities.Vector2;

public class Text  extends Drawable{

    private String _str = "";

    public String getText(){
        return _str;
    }

    public void setText(String s){
        _str = s;
    }

    public Text(Shape s, String str) {
        super(s);
        this._str = str;
        //TODO Auto-generated constructor stub
    }

    @Override
    public void drawShape(Graphics g) {
        // TODO Auto-generated method stub
        g.drawString(_str,10,20);
    }

    @Override
    public void setPos(Vector2 v) {
        // TODO Auto-generated method stub
        
    }

    
    
}
